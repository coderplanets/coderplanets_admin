// import React from 'react'
// import { shallow } from 'enzyme'

// import AdderCell from '../index'

describe('TODO <AdderCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
