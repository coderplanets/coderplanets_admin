/* avatar: 'http://coderplanets.oss-cn-beijing.aliyuncs.com/mock/avatar1-15.png', */

const users = [
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/1.jpg',
    nickname: 'mydearxym',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/2.jpg',
    nickname: 'messi',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/3.jpg',
    nickname: 'iniesta',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/4.jpg',
    nickname: 'montu',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/5.jpg',
    nickname: 'fjiek',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/6.jpg',
    nickname: 'noone',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/7.jpg',
    nickname: 'noone',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/8.jpg',
    nickname: 'noone',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/9.jpg',
    nickname: 'noone',
  },
  {
    avatar:
      'https://coderplanets.oss-cn-beijing.aliyuncs.com/icons/fakeuser/10.jpg',
    nickname: 'noone',
  },
]

export default users
