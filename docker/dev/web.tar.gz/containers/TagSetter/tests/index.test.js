// import React from 'react'
// import { shallow } from 'enzyme'

// import TagSetter from '../index'

describe('TODO <TagSetter />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
