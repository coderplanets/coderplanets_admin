/*
* TagSetterStore store test
*
*/

// import R from 'ramda'

// import TagSetterStore from '../index'

it('TODO: test TagSetterStore', () => {
  expect(1 + 1).toBe(2)
})
