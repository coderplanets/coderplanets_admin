// import React from 'react'
// import { shallow } from 'enzyme'

// import AccountViewer from '../index'

describe('<AccountViewer />', () => {
  it('TODO Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
