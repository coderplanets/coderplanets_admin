// import React from 'react'
// import { shallow } from 'enzyme'

// import CategoryEditor from '../index'

describe('TODO <CategoryEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
