/*
* PermissionEditorStore store test
*
*/

// import R from 'ramda'

// import PermissionEditorStore from '../index'

it('TODO: test PermissionEditorStore', () => {
  expect(1 + 1).toBe(2)
})
