/*
* CommunitiesBannerStore store test
*
*/

// import R from 'ramda'

// import CommunitiesBannerStore from '../index'

it('TODO: test CommunitiesBannerStore', () => {
  expect(1 + 1).toBe(2)
})
