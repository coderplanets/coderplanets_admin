// import React from 'react'
// import { shallow } from 'enzyme'

// import Content from '../index'

describe('TODO <Content />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
