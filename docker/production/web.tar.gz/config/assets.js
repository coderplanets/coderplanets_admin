export const ASSETS_ENDPOINT =
  'https://coderplanets.oss-cn-beijing.aliyuncs.com'

export const ICON_ASSETS = `${ASSETS_ENDPOINT}/icons`

export const DEFAULT_ICON = `${ASSETS_ENDPOINT}/icons/cmd/cheatsheet.svg`
