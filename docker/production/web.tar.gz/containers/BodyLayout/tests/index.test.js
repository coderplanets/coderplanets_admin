// import React from 'react'
// import { shallow } from 'enzyme'

// import BodyLayout from '../index'

describe('<BodyLayout />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
