/*
* CommunityBannerStore store test
*
*/

// import R from 'ramda'

// import CommunityBannerStore from '../index'

it('TODO: test CommunityBannerStore', () => {
  expect(1 + 1).toBe(2)
})
