/*
* TypeWriterStore store test
*
*/

// import R from 'ramda'

// import TypeWriterStore from '../index'

it('TODO: test TypeWriterStore', () => {
  expect(1 + 1).toBe(2)
})
