// import React from 'react'
// import { shallow } from 'enzyme'

// import Banner from '../index'

describe('TODO <Banner />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
