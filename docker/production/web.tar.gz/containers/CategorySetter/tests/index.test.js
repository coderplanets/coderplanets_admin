// import React from 'react'
// import { shallow } from 'enzyme'

// import CategorySetter from '../index'

describe('TODO <CategorySetter />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
