/*
* AccountEditorStore store test
*
*/

// import R from 'ramda'

// import AccountEditorStore from '../index'

it('TODO: test AccountEditorStore', () => {
  expect(1 + 1).toBe(2)
})
