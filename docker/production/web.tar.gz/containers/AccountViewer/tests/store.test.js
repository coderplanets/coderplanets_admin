/*
* AccountViewerStore store test
*
*/

// import R from 'ramda'

// import AccountViewerStore from '../index'

it('TODO: test AccountViewerStore', () => {
  expect(1 + 1).toBe(2)
})
