// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunitiesContent from '../index'

describe('TODO <CommunitiesContent />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
