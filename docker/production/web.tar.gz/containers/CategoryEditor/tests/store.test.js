/*
* CategoryEditorStore store test
*
*/

// import R from 'ramda'

// import CategoryEditorStore from '../index'

it('TODO: test CategoryEditorStore', () => {
  expect(1 + 1).toBe(2)
})
