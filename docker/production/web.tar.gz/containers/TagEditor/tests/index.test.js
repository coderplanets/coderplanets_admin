// import React from 'react'
// import { shallow } from 'enzyme'

// import TagEditor from '../index'

describe('TODO <TagEditor />', () => {
  it('-Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
