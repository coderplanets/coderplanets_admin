// import React from 'react'
// import { shallow } from 'enzyme'

// import PermissionEditor from '../index'

describe('TODO <PermissionEditor />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
