// import React from 'react'
// import { shallow } from 'enzyme'

// import MaybeCell from '../index'

describe('TODO <MaybeCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
