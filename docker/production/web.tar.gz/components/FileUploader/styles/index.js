import styled from 'styled-components'

export const FileUploaderWrapper = styled.div``
export const InputFile = styled.input`
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
`
