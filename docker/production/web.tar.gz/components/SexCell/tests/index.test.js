// import React from 'react'
// import { shallow } from 'enzyme'

// import SexCell from '../index'

describe('TODO <SexCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
