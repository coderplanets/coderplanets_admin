// import React from 'react'
// import { shallow } from 'enzyme'

// import PermissionCell from '../index'

describe('TODO <PermissionCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
