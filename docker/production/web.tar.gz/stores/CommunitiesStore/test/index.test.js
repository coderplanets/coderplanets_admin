/*
* CommunityStore store test
*
*/

// import CommunityStore from '../index'

it('1 + 1 = 2', () => {
  expect(1 + 1).toBe(2)
})
