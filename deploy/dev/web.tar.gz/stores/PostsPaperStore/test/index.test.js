/*
* PostsPaperStore store test
*
*/

// import R from 'ramda'

// import PostsPaperStore from '../index'

it('TODO: test PostsPaperStore', () => {
  expect(1 + 1).toBe(2)
})
