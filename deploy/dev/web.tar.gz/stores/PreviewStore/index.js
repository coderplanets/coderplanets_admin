/*
 * PreviewStore store
 *
 */

import { types as t, getParent } from 'mobx-state-tree'

// import { CMS_THREADS } from '../../config'

import { Community, Category, Tag, Post, User } from '../SharedModel'
import { markStates, TYPE, unholdPage, stripMobx } from '../../utils'

// const debug = makeDebugger('S:PreviewStore')
const Article = t.model('Article', {
  thread: t.string, // t.optional(t.enumeration('thread', CMS_THREADS), CMS_THREADS[0]),
  data: Post,
})

const EditPermission = t.model('EditPermission', {
  type: t.string, // TODO: enumeration
  data: User,
})

const PreviewStore = t
  .model('PreviewStore', {
    visible: t.optional(t.boolean, false),
    type: t.maybe(
      t.enumeration('previewType', [
        TYPE.POST_PREVIEW_VIEW,
        TYPE.PREVIEW_ACCOUNT_VIEW,
        TYPE.PREVIEW_ACCOUNT_EDIT,
        TYPE.PREVIEW_ROOT_STORE,
        TYPE.PREVIEW_CREATE_POST,
        TYPE.PREVIEW_CREATE_COMMUNITY,
        TYPE.PREVIEW_UPDATE_COMMUNITY,
        // community
        TYPE.PREVIEW_SET_COMMUNITY,
        // tag
        TYPE.PREVIEW_SET_TAG,
        TYPE.PREVIEW_CREATE_TAG,
        TYPE.PREVIEW_UPDATE_TAG,
        // category
        TYPE.PREVIEW_CREATE_CATEGORY,
        TYPE.PREVIEW_SET_CATEGORY,
        TYPE.PREVIEW_UPDATE_CATEGORY,
        // thread
        TYPE.PREVIEW_SET_THREAD,
        // permission
        TYPE.PREVIEW_CREATE_PERMISSION,
        TYPE.PREVIEW_UPDATE_PERMISSION,
      ])
    ),
    editCommunity: t.maybe(Community),
    editCategory: t.maybe(Category),
    editTag: t.maybe(Tag),
    editArticle: t.maybe(Article),
    editPermission: t.maybe(EditPermission),
    /* editCategory: t.maybe(SelectCommunity), */
  })
  .views(self => ({
    get root() {
      return getParent(self)
    },
    get rootState() {
      return stripMobx(self.root)
    },
    get editCommunityData() {
      return stripMobx(self.editCommunity)
    },
    get editCategoryData() {
      return stripMobx(self.editCategory)
    },
    get editTagData() {
      return stripMobx(self.editTag)
    },
    get editArticleData() {
      return stripMobx(self.editArticle)
    },
    get editPermissionData() {
      return stripMobx(self.editPermission)
    },
    get themeKeys() {
      return self.root.theme.themeKeys
    },
    get curTheme() {
      return self.root.theme.curTheme
    },
  }))
  .actions(self => ({
    open(type = TYPE.POST_PREVIEW_VIEW) {
      self.visible = true
      self.type = type
    },
    close() {
      self.visible = false
      // self.type = TYPE.PREVIEW_ROOT_STORE
      unholdPage()
    },
    markState(sobj) {
      markStates(sobj, self)
    },
  }))

export default PreviewStore
