/*
* ApiLayoutStore store test
*
*/

// import R from 'ramda'

// import ApiLayoutStore from '../index'

it('TODO: test ApiLayoutStore', () => {
  expect(1 + 1).toBe(2)
})
