/*
* TutsViewerStore store test
*
*/

// import R from 'ramda'

// import TutsViewerStore from '../index'

it('TODO: test TutsViewerStore', () => {
  expect(1 + 1).toBe(2)
})
