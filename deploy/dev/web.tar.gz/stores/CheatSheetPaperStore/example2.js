const fuck = `
# H1
  这里是正文啊
  > 这里是引用
## H2
### H3
#### H4
##### H5

 - [ ] djfiefe
 - [x] djfiefe


Start numbering with offset:

+ Create a list by starting a line with

+ Sub-lists are made by indenting 2 spaces:
  - Marker character change forces new list start:
    * Ac tristique libero volutpat at
    + Facilisis in pretium nisl aliquet
    - Nulla volutpat aliquam velit
+ Very easy!


###### H6

Alternatively, for H1 and H2, an underline-ish style:

Emphasis, aka italics, with *asterisks* or _underscores_.

Strong emphasis, aka bold, with **asterisks** or __underscores__.

Combined emphasis with **asterisks and _underscores_**.

Strikethrough uses two tildes. ~~Scratch this.~~

Alt-H1
======

1. First ordered list item
   1. ordered list item
   2. ordered list item

2. Another item
⋅⋅* Unordered sub-list.
1. Actual numbers dont matter, just that its a number
⋅⋅1. Ordered sub-list
4. And another item.


* Unordered list can use asterisks
  * fiej
  * fiej

* Or minuses

  [Im an inline-style link](https://www.google.com)


| Option | Description |
| ------ | ----------- |
| data   | path to data files to supply the data that will be passed into templates. |
| engine | engine to be used for processing templates. Handlebars is the default. |
| ext    | extension to be used for dest files. |

| Option | Description |
| ------:| -----------:|
| data   | path to data files to supply the data that will be passed into templates. |
| engine | engine to be used for processing templates. Handlebars is the default. |
| ext    | extension to be used for dest files. |


> **Note:**
> - Full access to **Google Drive** or **Dropbox** is required to be able to import any document in StackEdit. Permission restrictions can be configured in the settings.
> - Imported documents are downloaded in your browser and are not transmitted to a server.
> - If you experience problems saving your documents on Google Drive, check and optionally disable browser extensions, such as Disconnect.

[this works](data:text/html;base64,PHNjcmlwdD5hbGVydCgiSGVsbG8iKTs8L3NjcmlwdD4K)

![Minion](https://octodex.github.com/images/minion.png)
![Stormtroopocat](https://octodex.github.com/images/stormtroopocat.jpg 'The Stormtroopocat')

------
`

export default fuck
