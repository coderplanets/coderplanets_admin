/*
* HeaderStore store test
*
*/

// import R from 'ramda'
// import HeaderStore from '../index'

it('HeaderStore todo: 1 + 1 = 2', () => {
  expect(1 + 1).toBe(2)
})
