/*
* JobsViewerStore store test
*
*/

// import R from 'ramda'
// import JobsViewerStore from '../index'

it('TODO: test JobsViewerStore', () => {
  expect(1 + 1).toBe(2)
})
