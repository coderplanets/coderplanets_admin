/*
* PostsStore store test
*
*/

// import R from 'ramda'

// import PostsStore from '../index'

it('TODO: test PostsStore', () => {
  expect(1 + 1).toBe(2)
})
