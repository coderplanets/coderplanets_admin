import shortid from 'shortid'

const uid = {
  gen: shortid.generate,
}

export default uid
