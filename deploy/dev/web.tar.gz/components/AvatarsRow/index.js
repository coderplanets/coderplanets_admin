/*
 *
 * AvatarsRow
 *
 */

import React from 'react'
import PropTypes from 'prop-types'
import R from 'ramda'

import { ATATARS_LIST_LENGTH } from '../../config/general'

import { Tooltip } from '../../components'
import { Avatars, AvatarsItem, AvatarsImg, AvatarsMore } from './styles'

/* eslint-disable no-unused-vars */
import { makeDebugger, prettyNum, uid } from '../../utils'

const debug = makeDebugger('c:AvatarsRow:index')
/* eslint-enable no-unused-vars */

const validUser = R.compose(R.not, R.isNil)

const AvatarsRow = ({
  users,
  total,
  height,
  limit,
  onUserSelect,
  onTotalSelect,
}) => {
  if (users.length === 0) {
    return <span />
  }

  users = R.filter(validUser, users)
  return (
    <Avatars height={height}>
      {total <= users.length ? (
        <span />
      ) : (
        <AvatarsItem onClick={onTotalSelect.bind(this, { users, total })}>
          <AvatarsMore>{prettyNum(total)}</AvatarsMore>
        </AvatarsItem>
      )}

      {R.slice(0, limit, R.reverse(users)).map(user => (
        <AvatarsItem key={uid.gen()} onClick={onUserSelect.bind(this, user)}>
          <Tooltip title={user.nickname}>
            <AvatarsImg src={user.avatar} />
          </Tooltip>
        </AvatarsItem>
      ))}
    </Avatars>
  )
}

AvatarsRow.propTypes = {
  users: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string,
      avatar: PropTypes.string,
      nickname: PropTypes.string,
      extra_id: PropTypes.string,
    })
  ),
  total: PropTypes.number.isRequired,
  height: PropTypes.string,
  limit: PropTypes.number,
  onUserSelect: PropTypes.func,
  onTotalSelect: PropTypes.func,
}

AvatarsRow.defaultProps = {
  height: '32px',
  users: [],
  limit: ATATARS_LIST_LENGTH.POSTS,
  onUserSelect: debug,
  onTotalSelect: debug,
}

export default AvatarsRow
