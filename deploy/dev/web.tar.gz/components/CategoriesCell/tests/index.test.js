// import React from 'react'
// import { shallow } from 'enzyme'

// import CategoriesCell from '../index'

describe('TODO <CategoriesCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
