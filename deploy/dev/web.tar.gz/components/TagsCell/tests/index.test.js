// import React from 'react'
// import { shallow } from 'enzyme'

// import TagsCell from '../index'

describe('TODO <TagsCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
