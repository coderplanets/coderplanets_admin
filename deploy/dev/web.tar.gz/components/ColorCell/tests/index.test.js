// import React from 'react'
// import { shallow } from 'enzyme'

// import ColorCell from '../index'

describe('TODO <ColorCell />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
