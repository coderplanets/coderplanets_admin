/*
 *
 * LoadingEffects
 *
 */

export { default as CheatSheetLoading } from './CheatSheetLoading'
export { default as CommentLoading } from './CommentLoading'
export { default as PostLoading } from './PostLoading'
export { default as PostsLoading } from './PostsLoading'

export { default as TableLoading } from './TableLoading'
