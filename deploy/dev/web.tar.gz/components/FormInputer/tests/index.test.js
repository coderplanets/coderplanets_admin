// import React from 'react'
// import { shallow } from 'enzyme'

// import FormInputer from '../index'

describe('TODO <FormInputer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
