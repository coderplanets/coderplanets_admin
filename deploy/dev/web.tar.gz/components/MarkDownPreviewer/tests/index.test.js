// import React from 'react'
// import { shallow } from 'enzyme'

// import MarkDownPreviewer from '../index'

describe('TODO <MarkDownPreviewer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
