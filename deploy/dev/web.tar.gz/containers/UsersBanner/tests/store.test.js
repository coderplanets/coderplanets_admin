/*
* UsersBannerStore store test
*
*/

// import R from 'ramda'

// import UsersBannerStore from '../index'

it('TODO: test UsersBannerStore', () => {
  expect(1 + 1).toBe(2)
})
