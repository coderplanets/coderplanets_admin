/*
* CommunityEditorStore store test
*
*/

// import R from 'ramda'

// import CommunityEditorStore from '../index'

it('TODO: test CommunityEditorStore', () => {
  expect(1 + 1).toBe(2)
})
