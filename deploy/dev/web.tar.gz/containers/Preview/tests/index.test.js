// import React from 'react'
// import { shallow } from 'enzyme'

// import Preview from '../index'

describe('<Preview />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
