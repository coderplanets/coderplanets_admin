// import React from 'react'
// import { shallow } from 'enzyme'

// import CommunityBanner from '../index'

describe('TODO <CommunityBanner />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
