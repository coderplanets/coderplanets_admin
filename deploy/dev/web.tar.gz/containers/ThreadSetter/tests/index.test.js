// import React from 'react'
// import { shallow } from 'enzyme'

// import ThreadSetter from '../index'

describe('TODO <ThreadSetter />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
