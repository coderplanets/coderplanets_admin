/*
* ThreadSetterStore store test
*
*/

// import R from 'ramda'

// import ThreadSetterStore from '../index'

it('TODO: test ThreadSetterStore', () => {
  expect(1 + 1).toBe(2)
})
