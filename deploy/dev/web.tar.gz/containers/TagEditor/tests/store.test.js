/*
* TagEditorStore store test
*
*/

// import R from 'ramda'

// import TagEditorStore from '../index'

it('TODO: test TagEditorStore', () => {
  expect(1 + 1).toBe(2)
})
