// import React from 'react'
// import { shallow } from 'enzyme'

// import CheatSheetContent from '../index'

describe('TODO <CheatSheetContent />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(true)
  })
})
