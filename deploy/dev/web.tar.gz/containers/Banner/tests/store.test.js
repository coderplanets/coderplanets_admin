/*
* BannerStore store test
*
*/

// import R from 'ramda'
// import BannerStore from '../index'

it('BannerStore 1 + 1 = 2', () => {
  expect(1 + 1).toBe(2)
})
