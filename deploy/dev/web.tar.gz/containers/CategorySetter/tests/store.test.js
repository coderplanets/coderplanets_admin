/*
* CategorySetterStore store test
*
*/

// import R from 'ramda'

// import CategorySetterStore from '../index'

it('TODO: test CategorySetterStore', () => {
  expect(1 + 1).toBe(2)
})
