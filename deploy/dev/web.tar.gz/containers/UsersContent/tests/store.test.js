/*
* UsersContentStore store test
*
*/

// import R from 'ramda'

// import UsersContentStore from '../index'

it('TODO: test UsersContentStore', () => {
  expect(1 + 1).toBe(2)
})
